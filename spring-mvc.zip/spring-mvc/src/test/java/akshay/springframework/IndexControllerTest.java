package akshay.springframework;

public class IndexControllerTest {
}
